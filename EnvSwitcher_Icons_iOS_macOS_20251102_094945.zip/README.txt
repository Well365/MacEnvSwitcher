Env Switcher Icons (iOS + macOS)
Generated: 20251102_094945

Folders:
- iOS_AppIcon.appiconset/: drag this entire folder into your Xcode Assets.xcassets for iPhone/iPad.
- macOS_AppIcon.appiconset/: drag into your Mac app's Assets.xcassets.

Notes:
- All PNGs are flattened (no alpha) to satisfy App Store requirements.
- The base image was auto-cropped to remove surrounding white margins.
- You can replace the base in the future and re-run to regenerate.

Enjoy!